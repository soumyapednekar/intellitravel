from django.shortcuts import render, HttpResponse
import requests
import datetime
# Create your views here.
def home(request):
     
     return render(request,'main_page_temp/index.html')
   # return HttpResponse("home page ")

def aboutus(request):
    return render(request,'main_page_temp/aboutus.html')


def ContactUs(request):
       return render(request,'main_page_temp/contactus.html')

def budget_tracker(request):
    return render(request,'budget_tracker/expense_list.html')
#################################################
##surshita

def notes(request):
    return render(request,'notes/notes.html')

def weather(request):
    if 'city' in request.POST:
        city = request.POST['city']
    else:
        city = 'Amsterdam'

    appid = 'b0b19263af01ceb1cd60327186913867'
    URL = 'https://api.openweathermap.org/data/2.5/weather'
    PARAMS = {'q':city,'appid':appid,'units':'metric'}
    r = requests.get(url=URL,params=PARAMS)
    res = r.json()
    description = res['weather'][0]['description']
    icon = res['weather'][0]['icon']
    temp = res['main']['temp']

    day = datetime.date.today()

    return render(request,'weather/weather.html',{'description':description,
    'icon':icon, 'temp':temp, 'day':day, 'city':city}
    )

from django.contrib import admin
from django.urls import path
from home import views

"""
     here path is blank so call index function.
     path(" this is written in search broweser",views.function_name, name=)
    """
urlpatterns =[ path("",views.home,name='home'),
path("home",views.home,name='home'),
path("aboutus",views.aboutus,name='aboutus'),
path("contactus",views.ContactUs,name='contactus'),
path("budgettracker",views.budget_tracker,name='budgettracker'),
path("notes",views.notes,name='notes'),
path("weather",views.weather,name='weather')
]




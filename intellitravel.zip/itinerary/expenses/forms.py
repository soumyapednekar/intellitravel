from django import forms
from .models import Expense, Category
class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ['date', 'category', 'description', 'amount']
        widgets = {
            'date': forms.TextInput(attrs={'type': 'date'}),
        }
class ExpenseEditForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ['date', 'category', 'description', 'amount']
        widgets = {
            'date': forms.TextInput(attrs={'type': 'date'}),
        }

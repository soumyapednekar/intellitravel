from django.shortcuts import render
##budget tracker views
from django.shortcuts import render, redirect,get_object_or_404
from django.urls import reverse
from django.contrib import messages
from django.core.paginator import Paginator
from .models import Expense, Category
from .forms import ExpenseForm, ExpenseEditForm
###
# Create your views here.
def expense_list(request):
    expenses = Expense.objects.all()
    categories = Category.objects.all()
    page = request.GET.get('page', 1)

    paginator = Paginator(expenses, 10)
    expenses = paginator.get_page(page)

    '''context = {'expenses': expenses, 'categories': categories}
    return render(request, 'budget_tracker/expense_list.html', context)'''
    expenses = Expense.objects.all()
    return render(request, 'budget_tracker/expense_list.html', {'expenses': expenses})
    

def expense_add(request):
   
    if request.method == 'POST':
        date = request.POST.get('date')
        category_id = request.POST.get('category')
        description = request.POST.get('description')
        amount = request.POST.get('amount')

        category = Category.objects.get(pk=category_id)
        expense = Expense(date=date, category=category, description=description, amount=amount)
        expense.save()
        messages.success(request, 'Expense added successfully!')
        return redirect(reverse('expenses'))

    categories = Category.objects.all()
    context = {'categories': categories}
    return render(request, 'budget_tracker/expense_form.html', context)

def expense_add(request): 
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save()
            expense.save()
            messages.success(request, 'Expense added successfully!')
            expenses = Expense.objects.all()
            return render(request, 'budget_tracker/expense_list.html', {'expenses': expenses})
    else:
        form = ExpenseForm()
        return render(request, 'budget_tracker/expense_add.html', {'form': form})



def expense_edit(request, expense_id):
    print(request.method)
    expense = Expense.objects.get(pk=expense_id)

    if request.method == 'POST':
        expense.date = request.POST.get('date')
        category_id = request.POST.get('category')
        expense.category = Category.objects.get(pk=category_id)
        expense.description = request.POST.get('description')
        expense.amount = request.POST.get('amount')
        expense.save()
        messages.success(request, 'Expense updated successfully!')
        expenses = Expense.objects.all()
        return render(request, 'budget_tracker/expense_list.html', {'expenses': expenses})

        '''return redirect(reverse('budget_tracker/expense_list'))'''

    categories = Category.objects.all()
    context = {'expense': expense, 'categories': categories}
    expense = get_object_or_404(Expense, pk=expense_id)
    if request.method == 'POST':
        form = ExpenseEditForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            messages.success(request, 'Expense edited successfully!')
            return redirect('budget_tracker/expense_list')
    else:
        form = ExpenseEditForm(instance=expense)
        return render(request, 'budget_tracker/expense_edit.html', {'form': form, 'expense': expense})





def expense_delete(request, expense_id):

    expense = Expense.objects.get(id=expense_id)
    if request.method == 'GET':
        expense.delete()
        '''return redirect(reverse('budget_tracker:expense_list'))'''
    expenses = Expense.objects.all()
    return render(request, 'budget_tracker/expense_list.html', {'expenses': expenses})
    
'''
def expense_delete(request):
    expenses = Expense.objects.all()
    if request.method == 'POST':
        expense_id = request.POST.get('expense_id')
        expense = Expense.objects.get(id=expense_id)
        expense.delete()
    return render(request, 'expense_list.html', {'expenses': expenses})
    '''
from django.urls import path
from .views import expense_list, expense_add, expense_edit, expense_delete

urlpatterns = [
    path('', expense_list, name='expense_list'),
    path('add/', expense_add, name='expense_add'),
    path('edit/<int:expense_id>/', expense_edit, name='expense_edit'),
    path('delete/<int:expense_id>/', expense_delete, name='expense_delete'),
]



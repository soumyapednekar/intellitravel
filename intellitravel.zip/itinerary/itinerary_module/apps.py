from django.apps import AppConfig


class ItineraryModuleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'itinerary_module'

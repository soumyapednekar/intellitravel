from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpResponse
from datetime import datetime, timedelta
from .models import Itinerary, Location_to_visit, Bookings,cost_Trip

locations = Location_to_visit.objects.all()

location_array = [location.location for location in locations]
location_maxSpend = {location.location: location.max_to_Spend for location in locations}


# Create your views here.
def show_location(request):
    
    location_description ={

        location.location: location.description for location in locations
    }
    return render(request, 'itinerary_templates/locations.html', {'locations': location_description})

def show_itinerary(request, location_url):
        if request.method == 'POST':
            search_loc = request.POST.get('search')
            search_loc = search_loc.capitalize()
            current_url = request.build_absolute_uri()
            base_url = current_url[:-len('search/')]
            base_url = base_url+search_loc
           
            if search_loc in location_array:
                return redirect (base_url)
            else:
                return HttpResponse("Location not found")
        else:
            if location_url in location_array:
                maxSpend = int(location_maxSpend[location_url])
                return render(request, 'itinerary_templates/showitinerary.html', {'location': location_url, 'maxSpend': range(1, maxSpend+1)})
            else:
                return HttpResponse("Location not found")
    
def show_schedule(request, location_url):

    if request.method == 'POST':
        max_people = request.POST.get('max_people')
        max_days = request.POST.get('max_days')
    if location_url in location_array:
        itineraries= Itinerary.objects.filter(location__location=location_url)
        itineraries_array = [itinerary.title for itinerary in itineraries]
        itineraries_description = {itinerary.title: itinerary.description for itinerary in itineraries}
        itineraries_time = {itinerary.title: itinerary.time_to_spend for itinerary in itineraries}
        dict_itinerary = dict(list(itineraries_description.items())[:int(max_days)*2])
        itineraries_time_array = [[v1, v2] for v1, v2 in zip(itineraries_time.values(), list(itineraries_time.values())[1:])]
        dict_itinerary_array = [[key1, dict_itinerary[key1], key2, dict_itinerary[key2]] for key1, key2 in zip(dict_itinerary.keys(), list(dict_itinerary.keys())[1:]) if list(dict_itinerary.keys()).index(key1) % 2 == 0]
        dict_itinerary_array = dict_itinerary_array[:int(max_days)]
        itineraries_zipped = zip(dict_itinerary_array, itineraries_time_array )
        print(itineraries_zipped)

        return render(request, 'itinerary_templates/showschedule.html', {'location': location_url, 'max_people': max_people, 'max_days': (range(1, int(max_days)+1)), 'itineraries': itineraries_array, 'itineraries_zipped': itineraries_zipped })
    else:
        return HttpResponse("Location not found")
    
def cost_trip(request,location_url):
      if request.method == 'POST':
           max_days = request.POST.get('max_days')
           cost_Trip=max_days*1000
      else:
          print("not pasted")


def book_itinerary(request, location_url):
    if location_url in location_array:
        maxSpend = int(location_maxSpend[location_url])
        return render(request, 'itinerary_templates/bookitinerary.html', {'location': location_url, 'maxSpend': range(1, maxSpend+1)})
    else:
        return HttpResponse("Location not found")
    
def booked_itinerary(request, location_url):
    if request.method == 'POST':
        max_days = request.POST.get('max_days')
       # cost_Trip=request.GET['cost_trip']
    if location_url in location_array:
        date_str = request.POST.get('date')
        max_days = request.POST.get('max_days')
        date_obj = datetime.strptime(date_str, '%Y-%m-%d').date()
        end_date = date_obj + timedelta(days=int(max_days))
        
        booking_details = {
            'name': request.POST.get('name'),
            'email': request.POST.get('email'),
            'phone': request.POST.get('phone'),
            'going_with': request.POST.get('max_people'),
            'max_days': request.POST.get('max_days'),
            'start_date': date_obj.strftime('%d/%m/%Y'),
            'end_date': end_date.strftime('%d/%m/%Y'),
            'cost_trip':request.GET['cost_trip'],
            'location': location_url
        }
        
        booking_model = Bookings(
            name=booking_details['name'],
            email=booking_details['email'],
            phone=booking_details['phone'],
            going_with=booking_details['going_with'],
            max_days_to_spend=booking_details['max_days'],
            cost_trip=booking_details['cost_trip'],
            start_date=booking_details['start_date'],
            end_date=booking_details['end_date'],
            location=booking_details['location']
        )
        booking_model.save()
        

        return render(request, 'itinerary_templates/bookeditinerary.html', {'booked_by': booking_details })
    else:
        return HttpResponse("Location not found")

from django.contrib import admin

# Register your models here.
from .models import Itinerary, Location_to_visit, Bookings,cost_Trip
admin.site.register(Itinerary)
admin.site.register(Location_to_visit)
admin.site.register(Bookings)
admin.site.register(cost_Trip)

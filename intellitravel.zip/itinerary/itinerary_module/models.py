from django.db import models

# Create your models here.
class Itinerary(models.Model):
    title = models.CharField(max_length=100)
    location = models.ForeignKey('Location_to_visit', on_delete=models.CASCADE, default="")
    description = models.TextField()
    time_to_spend = models.CharField(max_length=100, default="")
    date = models.DateField("Date (DD/MM/YYYY)")

    def __str__(self):
        return self.title
    
    
class Location_to_visit(models.Model):
    location = models.CharField(max_length=100)
    max_to_Spend = models.CharField(max_length=100, default="")
    description = models.TextField()
    
    def __str__(self):
        return self.location
    
# 'name': request.POST.get('name'),
#             'email': request.POST.get('email'),
#             'phone': request.POST.get('phone'),
#             'going_with': request.POST.get('max_people'),
#             'max_days': request.POST.get('max_days'),
#             'start_date': date_obj.strftime('%d/%m/%Y'),
#             'end_date': end_date.strftime('%d/%m/%Y'),
#             'location': location_url
    

class cost_Trip(models.Model):
    cost_trip=models.CharField(max_length=100)
    def __str__(self):
        return self.cost_trip
    

    
class Bookings(models.Model):
    #def the attributes
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    going_with = models.CharField(max_length=100)
    max_days_to_spend = models.CharField(max_length=100)
    #cost_trip=models.CharField(max_length=100)
    start_date = models.CharField(max_length=100)
    end_date = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    
    def __str__(self):
        return self.name
    

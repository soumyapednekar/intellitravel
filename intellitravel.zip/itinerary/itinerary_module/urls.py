from django.urls import path
from . import views

urlpatterns = [
    path('', views.show_location ),
    path('show/<str:location_url>/', views.show_itinerary ),
    path('show/<str:location_url>/schedule', views.show_schedule ),
    
    path('book/<str:location_url>/', views.book_itinerary, name='book_itinerary'),
    path('book/<str:location_url>/booked', views.booked_itinerary, name='booked_itinerary'),
]